package com.jamie.scansavvy.presentation.gallery

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jamie.scansavvy.data.PictureRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class GalleryUiState {
    object Loading : GalleryUiState()
    data class Success(val imageUris: List<Uri>) : GalleryUiState()
    data class Error(val message: String) : GalleryUiState()
}

@HiltViewModel
class GalleryViewModel @Inject constructor(
    private val pictureRepository: PictureRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<GalleryUiState>(GalleryUiState.Loading)
    val uiState = _uiState.asStateFlow()

    init {
        loadImages()
    }

    fun loadImages() {
        viewModelScope.launch {
            _uiState.value = GalleryUiState.Loading
            pictureRepository.loadImages()
                .onSuccess { uris ->
                    _uiState.value = GalleryUiState.Success(uris)
                }
                .onFailure { exception ->
                    _uiState.value = GalleryUiState.Error(exception.message ?: "Failed to load images.")
                }
        }
    }
}