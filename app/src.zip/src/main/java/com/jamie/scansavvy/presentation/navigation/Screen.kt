package com.jamie.scansavvy.presentation.navigation


// A sealed class is used to define a restricted class hierarchy.
// This is perfect for defining the screens in our app, ensuring type safety.
sealed class Screen(val route: String) {
    object Camera : Screen("camera_screen")
    object Gallery : Screen("gallery_screen")

    // The viewer screen requires an image URI to know what to display.
    // We define its route structure here.
    object Viewer : Screen("viewer_screen/{imageUri}") {
        // Helper function to create the full route with a specific URI.
        fun createRoute(imageUri: String) = "viewer_screen/$imageUri"
    }
}