package com.jamie.scansavvy.presentation.camera

import androidx.lifecycle.ViewModel
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.RESULT_FORMAT_JPEG
import com.google.mlkit.vision.documentscanner.GmsDocumentScannerOptions.SCANNER_MODE_FULL
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

// This ViewModel is now only responsible for configuring the scanner.
@HiltViewModel
class CameraViewModel @Inject constructor() : ViewModel() {

    // Configure the ML Kit scanner options.
    val scannerOptions: GmsDocumentScannerOptions = GmsDocumentScannerOptions.Builder()
        .setScannerMode(SCANNER_MODE_FULL) // Use the full UI flow.
        .setResultFormats(RESULT_FORMAT_JPEG) // We want JPEG images as output.
        .setGalleryImportAllowed(true) // Allow users to import from their gallery.
        .setPageLimit(10) // Set a reasonable page limit.
        .build()
}