package com.jamie.scansavvy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.jamie.scansavvy.presentation.camera.CameraScreen
import com.jamie.scansavvy.presentation.gallery.GalleryScreen
import com.jamie.scansavvy.presentation.navigation.Screen
import com.jamie.scansavvy.presentation.viewer.ViewerScreen
import com.jamie.scansavvy.ui.theme.ScanSavvyTheme
import dagger.hilt.android.AndroidEntryPoint
import java.net.URLDecoder
import java.nio.charset.StandardCharsets

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ScanSavvyTheme {
                val navController = rememberNavController()
                NavHost(
                    navController = navController,
                    startDestination = Screen.Camera.route,
                    modifier = Modifier.fillMaxSize()
                ) {
                    composable(route = Screen.Camera.route) {
                        CameraScreen(navController = navController)
                    }

                    composable(route = Screen.Gallery.route) {
                        GalleryScreen(navController = navController)
                    }

                    composable(
                        route = Screen.Viewer.route,
                        arguments = listOf(navArgument("imageUri") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val encodedUri = backStackEntry.arguments?.getString("imageUri") ?: ""
                        // It is crucial to decode the URI string that was encoded for safe navigation.
                        val imageUri = URLDecoder.decode(encodedUri, StandardCharsets.UTF_8.toString())
                        ViewerScreen(
                            navController = navController,
                            imageUriString = imageUri
                        )
                    }
                }
            }
        }
    }
}