package com.jamie.scansavvy.presentation.viewer

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.net.toUri
import androidx.navigation.NavController
import coil.compose.AsyncImage
import com.mxalbert.zoomable.Zoomable
import com.mxalbert.zoomable.rememberZoomableState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ViewerScreen(
    navController: NavController,
    imageUriString: String
) {
    val imageUri = try {
        imageUriString.toUri()
    } catch (e: Exception) {
        println("Error parsing URI: ${e.message}")
        null
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { /* No title needed */ },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Black.copy(alpha = 0.3f)
                )
            )
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            if (imageUri != null) {
                // =====================================================================
                //           THE NEW IMPLEMENTATION USING ZOOMY
                // =====================================================================
                val zoomableState = rememberZoomableState()

                Zoomable(
                    state = zoomableState,
                    modifier = Modifier.fillMaxSize()
                ) {
                    // The content of this block is what will be made zoomable.
                    AsyncImage(
                        model = imageUri,
                        contentDescription = "Scanned Document",
                        // The modifier from Zoomable's scope must be applied here.
                        modifier = Modifier.fillMaxSize()
                    )
                }
            } else {
                Text(text = "Could not load image. Invalid URI.")
            }
        }
    }
}