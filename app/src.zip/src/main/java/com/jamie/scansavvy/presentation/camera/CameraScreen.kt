package com.jamie.scansavvy.presentation.camera

import android.app.Activity
import android.content.IntentSender
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Scanner
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.google.mlkit.vision.documentscanner.GmsDocumentScanning
import com.google.mlkit.vision.documentscanner.GmsDocumentScanningResult
import com.jamie.scansavvy.presentation.navigation.Screen
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

@Composable
fun CameraScreen(
    navController: NavController,
    viewModel: CameraViewModel = hiltViewModel()
) {
    val context = LocalContext.current

    val scannerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            // Use the correct API from the documentation
            val scanningResult = GmsDocumentScanningResult.fromActivityResultIntent(result.data)

            // Get the list of scanned pages
            scanningResult?.pages?.let { pages ->
                // For this app, we only care about the first page
                if (pages.isNotEmpty()) {
                    val firstPageUri = pages[0].imageUri
                    val encodedUri = URLEncoder.encode(firstPageUri.toString(), StandardCharsets.UTF_8.toString())
                    navController.navigate(Screen.Viewer.createRoute(encodedUri))
                }
            }

            // You could also handle the PDF result if you configured it in the options
            scanningResult?.pdf?.let { pdf ->
                // val pdfUri = pdf.uri
                // Handle the PDF URI
            }
        }
    }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Button(
            onClick = {
                val scanner = GmsDocumentScanning.getClient(viewModel.scannerOptions)
                scanner.getStartScanIntent(context as Activity)
                    .addOnSuccessListener { intentSender: IntentSender ->
                        scannerLauncher.launch(IntentSenderRequest.Builder(intentSender).build())
                    }
                    .addOnFailureListener {
                        println("Scanner failed to start: ${it.message}")
                    }
            },
            modifier = Modifier.size(width = 200.dp, height = 60.dp)
        ) {
            Icon(imageVector = Icons.Default.Scanner, contentDescription = "Scan Icon")
            Spacer(modifier = Modifier.size(8.dp))
            Text(text = "Scan Document")
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = { navController.navigate(Screen.Gallery.route) },
            modifier = Modifier.size(width = 200.dp, height = 60.dp)
        ) {
            Icon(imageVector = Icons.Default.PhotoLibrary, contentDescription = "Gallery Icon")
            Spacer(modifier = Modifier.size(8.dp))
            Text(text = "View Gallery")
        }
    }
}